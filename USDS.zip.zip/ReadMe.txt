Download and Unzip the USDS.zip into a regular windows folder that has read / write permission.

Starting with Software Take-Home Design Analysis And Implementation.doc in doc/Solution folder